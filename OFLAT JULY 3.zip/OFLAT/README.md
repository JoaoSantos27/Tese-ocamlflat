The OFLAT application
